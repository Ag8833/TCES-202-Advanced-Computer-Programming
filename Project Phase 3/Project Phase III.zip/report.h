/*
 * report.h
 *
 *  Created on: Mar 3, 2015
 *      Author: bwatt89
 *      Edited by: Andrew Gates and Brandon Watt
 */

#ifndef REPORT_H_
#define REPORT_H_

int report_main_menu();
int report_menu(void);


int print_report_menu(void);
int report_data(void);

#endif /* REPORT_H_ */
